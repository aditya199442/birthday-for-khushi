function startCelebration() {
  const audio = document.getElementById("birthdayAudio");
  audio.play().catch(e => console.log("Audio blocked by browser", e));
  alert("🎉 Happy Birthday Khushi! 🎉");
}

const countdownEl = document.getElementById("countdown");
const birthdayDate = new Date("2025-08-27T00:00:00");

function updateCountdown() {
  const now = new Date();
  const diff = birthdayDate - now;

  if (diff <= 0) {
    countdownEl.textContent = "🎉 It's Khushi's Birthday Today! 🎂";
    return;
  }

  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
  const minutes = Math.floor((diff / 1000 / 60) % 60);
  const seconds = Math.floor((diff / 1000) % 60);

  countdownEl.textContent = `${days}d ${hours}h ${minutes}m ${seconds}s left`;
}

setInterval(updateCountdown, 1000);
updateCountdown();